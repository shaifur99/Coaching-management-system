from django.db.models import (
    CharField,
    DecimalField,
    ForeignKey,
    CASCADE,
    TextChoices,
    SET_NULL,
    OneToOneField
)

from django.utils.translation import gettext_lazy as _
from common.models import DjangoBaseModel
from apps.student.models.student_model import StudentProfile
from common.custom_id import generate_custom_id

class PaymentStatusChoices(TextChoices):
    PAID = "paid", "Paid",
    PARTIAL_PAID = "partial_paid", "Partial Paid"
    DUE = "Due", "Due"

class StudentAccount(DjangoBaseModel):
    student = OneToOneField(StudentProfile, related_name="student_payment", on_delete=CASCADE)
    
    previous_due = DecimalField(
        max_digits=20,
        decimal_places=4,
        default=0.0000,
        blank=True,
        null=True
    )
    current_due = DecimalField(
        max_digits=20,
        decimal_places=4,
        default=0.0000,
        blank=True,
        null=True
    )
    paid_amount = DecimalField(
        max_digits=20,
        decimal_places=4,
        default=0.0000,
        blank=True,
        null=True
    )
    
    def get_current_due(self):
        current_due = (self.previous_due+ self.current_due)- self.paid_amount
        
        return round(current_due, 4)
    
    def __str__(self):
        return f"{self.student.student_user.name}-({self.student.student_user.username}) Accounts"

class StudentPayment(DjangoBaseModel):
    student = ForeignKey(StudentProfile, related_name="student_account", on_delete=CASCADE)
    invoice_id = CharField(max_length=30, unique=True, blank=True, null=True)
    total_fees = DecimalField(
        max_digits=20,
        decimal_places=4,
        default=0.0000,
        blank=True,
        null=True
    )
    previous_due = DecimalField(
        max_digits=20,
        decimal_places=4,
        default=0.0000,
        blank=True,
        null=True
    )
    current_due = DecimalField(
        max_digits=20,
        decimal_places=4,
        default=0.0000,
        blank=True,
        null=True
    )
    paid_amount = DecimalField(
        max_digits=20,
        decimal_places=4,
        default=0.0000,
        blank=True,
        null=True
    )
    payment_medium =  CharField(max_length=50, blank=True, null=True)
    payment_status = CharField(max_length=15, choices=PaymentStatusChoices.choices, default=PaymentStatusChoices.DUE, blank=True, null=True)
    transition_id = CharField(max_length=100, blank=True, null=True)
    
    def get_current_due(self):
        current_due = (self.previous_due+ self.current_due)- self.paid_amount
        
        return round(current_due, 4)
    
    def clean(self) -> None:
        if not self.invoice_id:
            self.invoice_id = generate_custom_id(id_prefix="INV", model_class=self.__class__, field="invoice_id")

        super().clean()

    def save(self, *args, **kwargs):
        """
        Override save to ensure clean is called before saving.
        """
        self.full_clean()  # Calls the clean method
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.invoice_id}"