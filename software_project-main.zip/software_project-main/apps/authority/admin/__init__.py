from apps.authority.admin.class_admin import InstituteAdmin, StudyClassAdmin
from apps.authority.admin.notice_admin import NoticeAdmin
from apps.authority.admin.course_admin import (
    CourseAdmin,
    BatchAdmin,
    WeekDaysAdmin,
    EnrolledStudentAdmin,
    SubmittedAssignmentAdmin,
)
from apps.authority.admin.payment_admin import (StudentAccountAdmin, StudentPaymentAdmin,)

__all__ = [
    "InstituteAdmin",
    "StudyClassAdmin",
    "NoticeAdmin",
    "CourseAdmin",
    "BatchAdmin",
    "WeekDaysAdmin",
    "EnrolledStudentAdmin",
    "SubmittedAssignmentAdmin",
    "StudentAccountAdmin",
    "StudentPaymentAdmin",
    # Add other related admin models here if necessary.
]
