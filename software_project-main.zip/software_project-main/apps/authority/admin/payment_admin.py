from django.contrib.admin import (
    ModelAdmin,
    # Methods
    register,
)

from apps.authority.models.payment_model import StudentAccount, StudentPayment


@register(StudentAccount)
class StudentAccountAdmin(ModelAdmin):
    """
    Admin interface for the Student Account Admin.
    """

    list_display = ('id', 'student', 'previous_due', 'current_due', 'paid_amount', )
    list_display_links = ("id",)
    search_fields = (
        "id",
        "student__student_user__username",
    )
    ordering = ("-id",)
    list_per_page = 50
    
@register(StudentPayment)
class StudentPaymentAdmin(ModelAdmin):
    """
    Admin interface for the Student Payment Admin.
    """

    list_display = ('id','student', 'invoice_id', 'total_fees', 'previous_due', 'current_due', 'paid_amount', 'payment_medium', 'payment_status', 'transition_id', )
    list_editable = ('payment_status',)
    list_display_links = ("id",)
    search_fields = (
        "id",
        "student__student_user__username",
    )
    ordering = ("-id",)
    list_filter = ("payment_status",)
    list_per_page = 50
