from apps.teacher.models.profile_model import (
    TeacherProfile,
    Address,
    EducationalQualification,
)


__all__ = ["TeacherProfile", "Address", "EducationalQualification"]
