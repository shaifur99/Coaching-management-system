from apps.teacher.admin.profile_admin import (
    TeacherProfileAdmin,
    AddressAdmin,
    EducationalQualificationAdmin,
)


__all__ = [
    "TeacherProfileAdmin",
    "AddressAdmin",
    "EducationalQualificationAdmin",
]
