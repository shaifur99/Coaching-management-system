from django.apps import AppConfig


class EndpointConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.endpoint"
