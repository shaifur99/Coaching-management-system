from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.contrib import messages
from django.db.models import Q

# Permissions and Authorization
from django.contrib.auth.mixins import LoginRequiredMixin

# custom UserpassTestMixin
from apps.student.permission import StudentPassesTestMixin

# class Based View
from django.views.generic import ListView
from django.views.generic import DetailView


# Models
from apps.authority.models.notice_model import (
    Notice,
    PublishedStatusChoice,
    NoticePublishedForChoice,
)
from apps.authority.models.payment_model import StudentAccount, StudentPayment


# Import Filter
from apps.authority.filters.notice_filter import NoticeFilter
from django.shortcuts import render
from django.shortcuts import redirect
from django.urls import reverse
from django.shortcuts import HttpResponseRedirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from apps.authority.models.payment_model import StudentAccount
# Packages for python
import requests
import socket
# from sslcommerz_python.payment import SSLCSession


class StudentAccountStatusView(LoginRequiredMixin, StudentPassesTestMixin, ListView):
    model = StudentAccount
    filterset_class = NoticeFilter
    template_name = "student/payment_status.html"
    context_object_name = "object"
    
    def get_queryset(self):
        # Dynamically filter based on the logged-in user
        return StudentAccount.objects.filter(student=self.request.user.student_profile).order_by("-id")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["title"] = "Student Account Details"
        return context


# @login_required
# def payment(request):

    

#     order_total = StudentAccount.objects.filter(student=request.user.student_profile).first()

    
#     status_url = request.build_absolute_uri(reverse('student:student_home'))
#     current_user = request.user
#     full_name = str(current_user.name)

#     mypayment = SSLCSession(sslc_is_sandbox=True, sslc_store_id='maste6822f6cf5f64f', sslc_store_pass='maste6822f6cf5f64f@ssl')

#     mypayment.set_urls(success_url=status_url, fail_url=status_url, cancel_url=status_url, ipn_url=status_url)

#     mypayment.set_product_integration(total_amount=Decimal(order_total), currency='BDT', product_category='food', product_name=order_items, num_of_item=order_items_count, shipping_method='YES', product_profile='None')

#     mypayment.set_customer_info(name=full_name, email=current_user.email, address1=current_user.profile.address_1, address2=current_user.profile.address_1, city='Dhaka', postcode='1230', country='Bangladesh', phone=current_user.profile.phone_number)

#     mypayment.set_shipping_info(shipping_to=full_name, address="uttara Dhaka", city="Dhaka", postcode="1230", country="Bangaladesh")

#     response_data = mypayment.init_payment()
#     print(response_data)

#     return redirect(response_data['GatewayPageURL'])