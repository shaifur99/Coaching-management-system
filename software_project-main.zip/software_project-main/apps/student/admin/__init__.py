from apps.student.admin.student_admin import StudentProfileAdmin


__all__ = [
    "StudentProfileAdmin",
]
