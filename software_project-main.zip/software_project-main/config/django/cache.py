from typing import Any
from pydantic import Field, computed_field
from pydantic_settings import BaseSettings
from config.django.database import db_config


class CacheSettings(BaseSettings):
    """
    This class defines the setting configuration for this auth service
    """

    
    CACHE_TTL: int = 60 * 1500  # Default time-to-live (in seconds)
    DEFAULT_CACHE_BACKEND: str = Field(
        default="django.core.cache.backends.db.DatabaseCache",
        frozen=True,
        repr=False,
    )

    @computed_field()
    def CACHES(self) -> dict[str, Any]:
        return {
            "default": {
                "BACKEND": self.DEFAULT_CACHE_BACKEND,
                "LOCATION": "default",
                "OPTIONS": {},
            },
        }


cache_config = CacheSettings()
